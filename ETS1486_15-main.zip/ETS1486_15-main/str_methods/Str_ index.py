text = "Hello, world!"
index = text.index("world")
print(index)  # Output: 7 because the word world exists after 7 characters 
