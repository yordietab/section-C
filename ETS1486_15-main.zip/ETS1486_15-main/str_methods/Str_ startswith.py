text = "Hello, world!"
print(text.startswith("Hello"))  # Output: True
print(text.startswith("world"))  # Output: False
