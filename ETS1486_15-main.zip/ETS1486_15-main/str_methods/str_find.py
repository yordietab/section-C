text = "Hello, world!"
index = text.find("world")
print(index)  # Output: 7
