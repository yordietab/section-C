text = "Hello, World!"
upper_text = text.upper()
print(upper_text)

#output: HELLO, WORLD!
