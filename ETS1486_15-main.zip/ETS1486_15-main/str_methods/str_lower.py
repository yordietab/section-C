text = "Hello, World!"
lower_text = text.lower()
print(lower_text)

#output: hello, world!
