text = "hello, world! python is fun."
title_text = text.title()
print(title_text)

#output: Hello, World! Python Is Fun.
